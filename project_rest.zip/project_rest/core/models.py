from django.conf import settings
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator

# Create your models here.

gender_choices = (
    ("male", "male"),
    ("female", "female"),
    ("None", "None")
)   

major_choices = (
    ("flutter", "flutter"),
    ("Ui/Ux", "Ui/Ux"),
    ("Graphic_Design", "Graphic_Design"),
    ("Civil_Engineering", "Civil_Engineering"),
    ("Android_Developer", "Android_Developer"),
    ("Django", "Django"),
    ("HR", "HR"),
)

notification_types = [
    ('general', 'General'),
    ('applications', 'Applications')
]

class CostumUser(AbstractUser):
    age = models.IntegerField(blank=True, null=True, default=20)
    location = models.CharField(max_length=200, blank=True, null=True, default="none")
    gender = models.CharField(max_length=20, choices=gender_choices, default="None", help_text="Gender")
    Your_major_type = models.CharField(max_length=20, choices=major_choices, default="HR")

    def __str__(self):
        return self.email

class Post(models.Model):
    full_name = models.CharField(max_length=40, blank=True, null=True)
    inf = models.TextField(max_length=1000, help_text="informations", blank=False, null=False, default="none")
    req = models.TextField(max_length=1000, help_text="requirments", blank=False, null=False, default="none")
    date = models.DateTimeField(auto_now_add=True, editable=False)
    user = models.ForeignKey(CostumUser, on_delete=models.CASCADE)
    email = models.EmailField(blank=False, null=False, default="none")
    locations = models.CharField(max_length=70)
    salary = models.DecimalField(decimal_places=2, max_digits=10, default=0.00)
    company_name = models.CharField(max_length=40, blank=False, null=False, default="none")
    time_work = models.IntegerField()
    major = models.CharField(max_length=50, choices=major_choices)
    is_published = models.BooleanField(default=True)
    published_at = models.DateTimeField(null=True, blank=True)
     
    def publish(self):
        for q in self.questions.all():
            if q.choices.count() < 2:
                raise ValueError(f"Question {q.id} needs at least 2 choices")
            if q.choices.filter(is_correct=True).count() != 1:
                raise ValueError(f"Question {q.id} must have exactly one correct choice")
        self.is_published = True
        self.published_at = timezone.now()
        self.save(update_fields=["is_published", "published_at"])

    def __str__(self):
        return self.company_name

class Profile(models.Model):
    user = models.ForeignKey(CostumUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    major = models.CharField(max_length=50, choices=major_choices, null=True, blank=True)
    Age = models.IntegerField()
    Email = models.EmailField(blank=False, null=False, default="none")
    location = models.CharField(max_length=150)

    def __str__(self):
        return self.name

class Recommonditions(models.Model):
    company_name = models.CharField(max_length=255)
    job = models.CharField(max_length=255)
    location = models.CharField(max_length=200)
    major = models.CharField(max_length=50, choices=major_choices)
    email = models.EmailField()
    working_hours = models.CharField(max_length=100)
    details = models.TextField()
    requirements = models.TextField()
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='recommonditions', null=True, blank=True)
    
    class Meta:
        indexes = [models.Index(fields=["major"])]
        verbose_name = "Recommondition"
        verbose_name_plural = "Recommonditions"
    
    def __str__(self):
        return f"{self.company_name} -> {self.major}"

class Application(models.Model):
    STATUS_CHOICES = [
        ('pending', 'pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="applications")
    recommondition = models.ForeignKey(Recommonditions, on_delete=models.CASCADE, related_name="applications", null=True, blank=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="applications", null=True, blank=True)
    message = models.TextField(blank=True, null=True)
    cv = models.FileField(upload_to='cvs/', validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])])
    status = models.CharField(max_length=20, default="pending", choices=STATUS_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        indexes = [
            models.Index(fields=["user", "post"]),
            models.Index(fields=["user", "recommondition"])
        ]
    
    def resolved_post(self):
        return self.post or (self.recommondition.post if self.recommondition else None)
    
    def __str__(self):
        return f"{self.user.email} - {self.status}"

class ApplicationAnswer(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey("Question", on_delete=models.CASCADE, related_name="application_answers")
    choice = models.ForeignKey("Choice", on_delete=models.CASCADE, related_name="application_answers")

    class Meta:
        unique_together = ("application", "question")
    
    def __str__(self):
        return f"{self.application.user.email} - {self.question.text}"

class Job(models.Model):
    hr = models.ForeignKey(CostumUser, on_delete=models.CASCADE, related_name="jobs")
    title = models.CharField(max_length=255)
    descriptions = models.TextField()
    location = models.CharField(max_length=255)
    requirements = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class Question(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='questions')
    text = models.CharField(max_length=500)

    def __str__(self):
        return f"Question for {self.post.company_name}: {self.text[:30]}"

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='choices')
    text = models.CharField(max_length=300)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.text

class Notifications(models.Model):
    user = models.ForeignKey(CostumUser, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=255)
    message = models.TextField()
    notification_type = models.CharField(max_length=30, choices=notification_types, default='general')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    post = models.ForeignKey(Post, null=True, blank=True, on_delete=models.SET_NULL, related_name="notifications")
    application = models.ForeignKey(Application, null=True, blank=True, on_delete=models.SET_NULL, related_name='notifications')
    
    def __str__(self):
        return f"{self.user.username} - {self.title}"