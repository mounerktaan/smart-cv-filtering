from django.urls import  path,include
from .views import *
from rest_framework.routers import DefaultRouter
from rest_framework.authtoken.views import obtain_auth_token

router=DefaultRouter()
urlpatterns = [
    path("posts/",list_post,name="list_post"),
    #path("posts/<int:pk>",post_detail,name="post_detail"),
    #path("products/",get_product_by_filter,name="get_product_by_filter"),
    path("api/regester",sign_up,name="sign"),
    path("api/log_in",log_in,name="log_in"),
    path("api/forgot_password",forgot_password,name="forgot_password"),
    path("api/reset_password",reset_password,name="reset_password"),
    path("posts/create_post",create_post,name="create_post"),
    path("api/profile",ProfileView.as_view(),name="profile"),
    path("api/notifications",NotificationsViews.as_view(),name="note"),
    path("api/un_read",get_unread_notifications,name="get_unread_notifications"),
    path("api/create_reco",create_recommondition,name="create_recommondition"),
    path("api/recommondition/<int:pk>",Recommonditionviews.as_view(),name="reco"),
    path("api/all_reco",get_all_recommonditions,name="all_reco"),
    path("api/",include(router.urls)),
    path("api/token",obtain_auth_token),
    path("api/get_job",get_job,name="get_job"),
    path("api/create_application",create_application,name="create_application"),
    path("api/accepted_applicants",accepted_applicants,name="accepted_applicants"),
    path("posts/delete_post",delete_post,name="delete_post"),
    path("posts/my_published_posts",my_published_posts,name="my_published_posts"),
    path("posts/my_posts_min",my_posts_min,name="my_posts_min"),


   
]