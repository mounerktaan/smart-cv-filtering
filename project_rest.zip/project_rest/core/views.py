from django.shortcuts import get_object_or_404, render
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from django.views.decorators.csrf import csrf_exempt
from rest_framework.permissions import IsAuthenticated, AllowAny
from .models import *
from .serializers import *
from django.contrib.auth.hashers import make_password, check_password
from rest_framework import status, viewsets
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token
import random
from django.core.cache import cache

# Create your views here.
@api_view(['POST'])
@permission_classes([AllowAny]) 
def sign_up(request):
    data = request.data
    serializer = SignUpSerial(data=data)

    if serializer.is_valid():
        if not CostumUser.objects.filter(username=data['email']).exists():
            user = CostumUser.objects.create(
                first_name=data['first_name'],
                last_name=data['last_name'],
                email=data['email'],
                username=data['email'],
                age=data['age'],
                location=data['location'],
                gender=data['gender'],
                Your_major_type=data['Your_major_type'],
                password=make_password(data['password'])
            )
            Profile.objects.create(
                user=user,
                name=user.first_name + " " + user.last_name,
                Age=user.age,
                location=user.location,
                Email=user.email,
                major=user.Your_major_type
            )
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                'id': user.id,
                'success': True,
                'token': token.key
            }, status=status.HTTP_201_CREATED)
        else:    
            return Response({
                'success': False,
                'error': "user is already exists"
            }, status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response({
            'success': False,
            'error': 'user error',
            'validation_errors': serializer.errors
        })

@api_view(['POST'])
@permission_classes([AllowAny]) 
def log_in(request):
    data = request.data
    
    if not data.get('email') or not data.get('password'):
        return Response({
            "success": False,
            "error": "Email and password are required"
        })
    
    if CostumUser.objects.filter(username=data['email']).exists():
        user = CostumUser.objects.get(username=data['email'])
        if check_password(data['password'], user.password):
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                'id': user.id,
                "success": True,
                'token': token.key
            })
        else:
            return Response({
                "success": False,
                "error": "wrong password"
            })
    else:
        return Response({
            "success": False,
            "error": "user not found"
        })

@api_view(['POST'])
@permission_classes([AllowAny])
def forgot_password(request):
    email = request.data.get('email')
    if not email:
        return Response({
            'success': False,
            'error': 'Email is required'
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        user = CostumUser.objects.get(email=email)
    except CostumUser.DoesNotExist:
        return Response({
            'success': False,
            'error': 'User not found'
        }, status=status.HTTP_404_NOT_FOUND)
    
    code = str(random.randint(100000, 999999))
    cache.set(f"reset_code_{email}", code, timeout=600)
    
    return Response({
        'success': True,
        'message': 'Code sent to email',
        'code': code
    }, status=status.HTTP_200_OK)

@api_view(['POST'])
@permission_classes([AllowAny])
def reset_password(request):
    email = request.data.get('email')
    code = request.data.get('code')
    new_password = request.data.get('new_password')

    if not all([email, code, new_password]):
        return Response({
            'success': False,
            'error': 'Missing data'
        }, status=status.HTTP_400_BAD_REQUEST)

    saved_code = cache.get(f"reset_code_{email}")
    if saved_code != code:
        return Response({
            'success': False,
            'error': 'Invalid or expired code'
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        user = CostumUser.objects.get(email=email)
        user.set_password(new_password)
        user.save()
        cache.delete(f"reset_code_{email}")
        return Response({
            'success': True,
            'message': 'Password reset successfully'
        })
    except CostumUser.DoesNotExist:
        return Response({
            'success': False,
            'error': 'User not found'
        }, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET']) 
@permission_classes([AllowAny]) 
def list_post(request):
    posts = Post.objects.all().prefetch_related("questions__choices")
    serializer = PostPublicSerializer(posts, many=True)
    return Response({
        'success': True,
        "data": serializer.data
    }, status=status.HTTP_200_OK)

@api_view(['POST']) 
@permission_classes([IsAuthenticated]) 
def create_post(request):
    serializer = PostSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        post = serializer.save()
        return Response({
            'success': True,
            'post_id': post.id,
        }, status=status.HTTP_201_CREATED)
    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)

class ProfileView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        try:
            user_profile = Profile.objects.get(user=request.user)
            serializer = ProfileSerializer(user_profile)
            return Response({
                'success': True,
                'data': serializer.data
            }, status=status.HTTP_200_OK)
        except Profile.DoesNotExist:
            return Response({
                'error': 'profile not found',
                'success': False
            }, status=status.HTTP_404_NOT_FOUND)

class NotificationsViews(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        notify_type = request.query_params.get('type')
        notifications = Notifications.objects.filter(user=request.user)
        notifications.filter(is_read=False).update(is_read=True)
        
        if notify_type:
            notifications = notifications.filter(notification_type=notify_type)
        
        notifications = notifications.order_by('-created_at')
        serializer = NotificationSerializer(notifications, many=True)
        return Response({
            'success': True,
            'data': serializer.data
        })
    
    def post(self, request):
        serializer = NotificationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response({
                'success': True,
                'data': serializer.data
            }, status=201)
        else:
            return Response({
                'success': False,
                'message_error': serializer.errors
            }, status=400)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_unread_notifications(request):
    unread_notifications = Notifications.objects.filter(user=request.user, is_read=False)
    serializer = NotificationSerializer(unread_notifications, many=True)
    return Response({
        'success': True,
        'data': serializer.data
    }, status=status.HTTP_200_OK)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_recommondition(request):
    try:
        serializer = Recommonditionserializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                'success': True,
                'data': serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            'success': False,
            'message_error': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({
            'error': str(e),
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class Recommonditionviews(APIView):
    def get(self, request, pk):
        try:
            recommondition = Recommonditions.objects.get(pk=pk)
        except Recommonditions.DoesNotExist:
            return Response({
                "error": "Recommondition not found",
                'success': False
            }, status=status.HTTP_404_NOT_FOUND)    
        
        serializer = Recommonditionserializer(recommondition)
        return Response({
            'success': True,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_recommonditions(request):
    p = Profile.objects.filter(user=request.user).first()
    user_major = getattr(p, "major", None) or getattr(request.user, "Your_major_type", None)
    
    if not user_major:
        return Response({
            'success': False,
            "error": "User major not set"
        }, status=400)
    
    data = Post.objects.filter(recommonditions__major=user_major).prefetch_related("questions__choices").distinct().order_by("-id")
    serializer = PostPublicSerializer(data, many=True)
    return Response({
        'success': True,
        'data': serializer.data
    }, status=status.HTTP_200_OK)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def create_application(request):
    serializer = ApplicationCreateSerializer(data=request.data, context={"request": request})
    if not serializer.is_valid():
        return Response({
            "success": False,
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)
    
    app = serializer.save()
    post = app.post or (app.recommondition.post if getattr(app, "recommondition", None) else None)
    
    # إنشاء إشعار للمتقدم
    Notifications.objects.create(
        user=request.user,
        title="Your request has been received",
        message=f"Your request has been received for: {post.inf if post else ''}",
        post=post,
        application=app
    )
    
    # إنشاء إشعار لصاحب العمل
    if post and post.user_id:
        applicant_name = (request.user.get_full_name() or request.user.username).strip()
        Notifications.objects.create(
            user=post.user,
            title="New employment application",
            message=f"{applicant_name} applied for the job : {post.inf}",
            post=post,
            application=app
        )
    
    if hasattr(app, "status") and app.status != "pending":
        app.status = "pending"
        app.save(update_fields=["status"])

    return Response({
        "success": True,
        "application_id": app.id
    }, status=status.HTTP_201_CREATED)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_job(request):
    qs = (
        Post.objects.filter(user=request.user)       
        .prefetch_related("questions__choices")
        .order_by("-id")
    )
    serializer = PostPublicSerializer(qs, many=True)          
    return Response({
        "success": True,
        "data": serializer.data
    }, status=status.HTTP_200_OK)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def accepted_applicants(request):
    post_id = request.data.get("post_id")
    threshold = float(request.data.get("threshold", 80)) 
    
    if not post_id:
        return Response({
            "success": False,
            "error": "post_id is required."
        }, status=400)
    
    post = get_object_or_404(Post.objects.prefetch_related("questions"), pk=post_id)
    
    if request.user != post.user and not request.user.is_staff:
        return Response({
            "success": False,
            "error": "Not allowed."
        }, status=403)
    
    total_questions = post.questions.count()
    if total_questions == 0:
        return Response({
            "success": True,
            "accepted": [],
            "total_questions": 0
        }, status=200)
    
    applications = Application.objects.filter(post=post).select_related("user").prefetch_related("answers__choice")
    accepted = []
    accepted_ids = set()
    
    for app in applications:
        correct = sum(1 for ans in app.answers.all() if ans.choice.is_correct)
        score = (correct / total_questions) * 100.0
        
        if score >= threshold:
            accepted.append({
                "app_id": app.id,
                "applicant_name": (app.user.get_full_name() or app.user.username).strip(),
                "email": app.user.email,
                "location": Profile.objects.filter(user=app.user).values_list("location", flat=True).first() or "غير محدد",
                "correct": correct,
                "total": total_questions,
                "score": round(score, 2),
            })
            accepted_ids.add(app.id)
    
    if hasattr(Application, "status"):
        Application.objects.filter(id__in=accepted_ids).exclude(status="accepted").update(status="accepted")
        Application.objects.filter(post=post).exclude(id__in=accepted_ids).exclude(status="rejected").update(status="rejected")
    
    for app in applications:
        new_status = "accepted" if app.id in accepted_ids else "rejected"
        if getattr(app, "status", None) != new_status:
            if new_status == "accepted":
                Notifications.objects.create(
                    user=app.user,
                    title="Your request has been accepted",
                    message=f"Congrats, Your request has been accepted : {post.inf}",
                    post=post,
                    application=app
                )
            else:
                Notifications.objects.create(
                    user=app.user,
                    title="Your request has been rejected",
                    message=f"Unfortunately, you do not meet the job requirements : {post.inf}",
                    post=post,
                    application=app
                )
    
    return Response({
        "success": True,
        "post_id": post.id,
        "total_questions": total_questions,
        "accepted": accepted
    }, status=200)

@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def delete_post(request):
    post_id = request.data.get("post_id")
    if not post_id:
        return Response({
            "success": False,
            "error": "post_id is required."
        }, status=status.HTTP_400_BAD_REQUEST)
    
    post = get_object_or_404(Post, pk=post_id)
    
    if post.user != request.user and not request.user.is_staff:
        return Response({
            "success": False,
            "error": "Not allowed."
        }, status=status.HTTP_403_FORBIDDEN)
    
    post.delete()
    return Response({
        "success": True,
        "message": "Post deleted."
    }, status=status.HTTP_200_OK)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def my_published_posts(request):
    qs = (
        Post.objects
        .filter(user=request.user, is_published=True)
        .prefetch_related("questions__choices")
        .order_by("-published_at", "-id")
    )
    serializer = PostPublicSerializer(qs, many=True)
    return Response({
        "success": True,
        "data": serializer.data
    }, status=status.HTTP_200_OK)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def my_notifications(request):
    qs = Notifications.objects.filter(user=request.user).order_by("-created_at")
    data = [{
        "id": n.id,
        "title": n.title,
        "message": n.message,
        "is_read": n.is_read,
        "created_at": n.created_at,
        "post_id": n.post_id,
        "application_id": n.application_id,
    } for n in qs]
    
    return Response({
        "success": True,
        "unread_count": qs.filter(is_read=False).count(),
        "data": data
    })

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def my_posts_min(request):
    posts = (
        Post.objects
        .filter(user=request.user)  
        .order_by("-id")
        .values("id", "major")
    )
    return Response({
        "success": True,
        "data": list(posts)
    }, status=status.HTTP_200_OK)