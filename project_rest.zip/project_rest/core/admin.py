from django.contrib import admin
from .models import *
# Register your models here.
#admin.site.register(Product)
admin.site.register(CostumUser)
admin.site.register(Post)
admin.site.register(Profile)
admin.site.register(Notifications)
admin.site.register(Recommonditions)
admin.site.register(Application)
admin.site.register(Job)
admin.site.register(Question)
admin.site.register(Choice)





    

