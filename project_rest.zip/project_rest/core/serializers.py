import json
from rest_framework import serializers
from django.db import transaction
from .models import *
from django.contrib.auth.hashers import make_password

class SignUpSerial(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)
    
    class Meta:
        model = CostumUser
        fields = ('id', 'first_name', 'last_name', 'email', 'age', 'location', 'password', 'gender', 'Your_major_type')
    
    def validate_email(self, value):
        if CostumUser.objects.filter(email=value).exists():
            raise serializers.ValidationError("User with this email already exists.")
        return value
    
    def create(self, validated_data):
        validated_data['password'] = make_password(validated_data['password'])
        validated_data['username'] = validated_data['email']
        return super().create(validated_data)

class LogninSerial(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = '__all__'

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notifications
        exclude = ['user']

class Recommonditionserializer(serializers.ModelSerializer):
    class Meta:
        model = Recommonditions
        fields = '__all__'

class ApplicationAnswerIn(serializers.Serializer):
    question = serializers.IntegerField()
    choice = serializers.IntegerField()

class ApplicationCreateSerializer(serializers.Serializer):
    post = serializers.IntegerField(required=False)
    recommondition = serializers.IntegerField(required=False)  
    cv = serializers.FileField(required=False)
    message = serializers.CharField(required=False, allow_blank=True)
    answers = ApplicationAnswerIn(many=True)

    def validate(self, attrs):
        raw_answers = self.initial_data.get("answers")
        if isinstance(raw_answers, str):
            try:
                attrs["answers"] = json.loads(raw_answers)
            except Exception:
                raise serializers.ValidationError({"answers": "Invalid JSON format."})

        post_id = attrs.get("post")
        rec_id = attrs.get("recommondition")
        if post_id and rec_id:
            raise serializers.ValidationError({"error": "Provide either post OR recommondition, not both."})
        if not post_id and not rec_id:
            raise serializers.ValidationError({"error": "Provide either post or recommondition."})
        
        if rec_id:
            try:
                rec = Recommonditions.objects.select_related("post").get(pk=rec_id)
            except Recommonditions.DoesNotExist:
                raise serializers.ValidationError({"recommondition": "Recommondition not found."})
            post = rec.post
            if not post:
                raise serializers.ValidationError({"recommondition": "This recommondition has no linked post."})
            attrs["recommondition_obj"] = rec
        else:
            try:
                post = Post.objects.get(pk=post_id, is_published=True)
            except Post.DoesNotExist:
                raise serializers.ValidationError({"post": "Post not found or not published."})
        
        attrs["post_obj"] = post
        answers = attrs["answers"]
        post_q_ids = set(post.questions.values_list("id", flat=True))
        
        if not post_q_ids:
            raise serializers.ValidationError({"post": "This post has no questions."})
        
        seen = set()
        for a in answers:
            q_id = a["question"]
            c_id = a["choice"]
            if q_id not in post_q_ids:
                raise serializers.ValidationError({"answers": f"Question {q_id} does not belong to this post."})
            if q_id in seen:
                raise serializers.ValidationError({"answers": f"Duplicate answer for question {q_id}."})
            seen.add(q_id)
            if not Choice.objects.filter(id=c_id, question_id=q_id).exists():
                raise serializers.ValidationError({"answers": f"Choice {c_id} does not belong to question {q_id}."})
        
        if len(seen) != len(post_q_ids):
            raise serializers.ValidationError({"answers": "You must answer all questions for this post."})
        
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        user = self.context["request"].user
        post = validated_data["post_obj"]
        rec = validated_data.get("recommondition_obj")
        answers = validated_data["answers"]

        # منع التقديم المكرر
        if rec:
            if Application.objects.filter(user=user, recommondition=rec).exists():
                raise serializers.ValidationError("You have already applied to this post.")
        else:
            if Application.objects.filter(user=user, post=post).exists():
                raise serializers.ValidationError("You have already applied to this post.")
        
        app = Application.objects.create(
            user=user,
            post=post if not rec else None,
            recommondition=rec if rec else None,
            cv=validated_data.get("cv", None),
            message=validated_data.get("message", ""),
        )
        
        ApplicationAnswer.objects.bulk_create([
            ApplicationAnswer(application=app, question_id=a["question"], choice_id=a["choice"])
            for a in answers
        ])

        return app

class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        exclude = ['hr']
        read_only_fields = ['hr', 'created_at']

class ChoicePublicSerializer(serializers.ModelSerializer):
    class Meta:
        model = Choice
        fields = ["id", "text"]

class ChoiceUSerializer(serializers.ModelSerializer):
    class Meta:
        model = Choice
        fields = ["text", "is_correct"]

class QuestionPublicSerializer(serializers.ModelSerializer):
    choices = ChoicePublicSerializer(many=True, read_only=True)
    
    class Meta:
        model = Question
        fields = ["id", "text", "choices"]

class QuestionSerializer(serializers.ModelSerializer):
    choices = ChoiceUSerializer(many=True, write_only=True)
    
    class Meta:
        model = Question
        fields = ['text', 'choices']

class PostSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, write_only=True)
    
    class Meta:
        model = Post
        exclude = ['user']  

    def create(self, validated_data):
        user = self.context['request'].user
        questions_data = validated_data.pop('questions', [])
        full_name = validated_data.pop('full_name', '').strip()
        
        if not full_name:
            full_name = f"{user.first_name} {user.last_name}".strip() or user.username
        
        major = validated_data.get('major')
        if not major:
            raise serializers.ValidationError({"major": "This field is required."})

        post = Post.objects.create(**validated_data, user=user, full_name=full_name)

        for qd in questions_data:
            choices = qd.pop('choices', [])
            q = Question.objects.create(post=post, **qd)
            
            if len(choices) < 2:
                raise serializers.ValidationError("Each question must have at least 2 choices.")
            
            if sum(1 for c in choices if c.get("is_correct") is True) != 1:
                raise serializers.ValidationError("Each question must have exactly one correct choice")
            
            Choice.objects.bulk_create([Choice(question=q, **c) for c in choices])

        Recommonditions.objects.create(
            post=post,
            major=major,
            company_name=getattr(post, "company_name", ""),
            job=getattr(post, "inf", ""),
            location=getattr(post, "locations", ""),
            email=getattr(post, "email", ""),
            working_hours=str(getattr(post, "time_work", "")),
            details=getattr(post, "inf", ""),
            requirements=getattr(post, "req", ""),
            salary=getattr(post, "salary", 0),
        )
        
        return post

class PostPublicSerializer(serializers.ModelSerializer):
    questions = QuestionPublicSerializer(many=True, read_only=True)
    
    class Meta:
        model = Post
        exclude = ['user', 'is_published', 'published_at']